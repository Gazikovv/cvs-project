const menu = document.querySelector('.burger');
const content = document.querySelector('.container');
const screens = document.querySelectorAll('.screen');

menu.addEventListener('click', () => {
    content.classList.toggle('active');
});

function replaceBig(id) {
    const bg = document.getElementById(id);
    screens.forEach(screen => {
        screen.style.display = 'none';
    })
    bg.style.display = 'block';
}

function changeBig() {
    const links = document.querySelectorAll('.link');

    links.forEach((link, index) => {
        link.addEventListener('mouseenter', i => {
            i.preventDefault()
            replaceBig(i.target.dataset.link);
        })
        link.addEventListener('click', i => {
            i.preventDefault();
            content.classList.toggle('active');
        })
    });

    screens.forEach( screen => {
        screen.style.display = 'none';
        screens[0].style.display = 'block';
    })
}

changeBig()
